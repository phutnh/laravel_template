<!DOCTYPE html>
<html>
<head>
  <title></title>
  @yield('styles')
</head>
<body>
  @yield('content')
  @yield('scripts')
</body>
</html>