@extends('front.layouts.app')

@section('content')
	<a href="{{ route('login') }}">Đăng nhập</a>
@endsection
