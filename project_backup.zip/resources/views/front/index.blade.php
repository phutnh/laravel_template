@extends('front.layouts.app')
@section('content')
@endsection