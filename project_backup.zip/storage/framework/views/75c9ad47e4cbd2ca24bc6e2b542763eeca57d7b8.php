<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <div class="block-header">
            <h5 class="card-title">Danh thông số hoa hồng</h5>
            <div class="block-tool">
              <!-- <a class="btn btn-success" href="#">Tạo mới</a> -->
            </div>
          </div>
          <table id="table-data-content" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Mã phần trăm</th>
                <th>Thông tin</th>
                <th>Giá trị</th>
                <th>Ngày tạo</th>
                <th>Ngày cập nhật</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>