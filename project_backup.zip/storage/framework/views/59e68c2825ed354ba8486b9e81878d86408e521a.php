<!DOCTYPE html>
<html>
<head>
  <title></title>
  <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>