
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset(config('setting.admin.path_js') . 'bootstrap-fileselect.js')); ?>"></script>
<script>
$('#dinhkem').fileselect({
  allowedFileExtensions: ['jpg', 'jpge', 'pdf', 'png', 'doc', 'docx'],
  browseBtnClass: 'btn btn-info',
  validationCallback: function (m, type, instance) {
    instance.$inputGroup
    .after('<span class="small text-danger">' + m + '</span>');
  }
});
$("#form-action-detail").ajaxForm({
  complete: function(response) {
    if (response.status == 200) {

      $("#ajax-messases").css({
        "display": "block"
      });

      messages = response.responseJSON.messages;
      $("#ajax-messases").find('.messases-text').html(messages);

      window.setTimeout(function() {
        $("#ajax-messases").css({
          "display": "none"
        });
      }, 3000);

      $('html, body').animate({
        scrollTop: 0
      }, 500);
      setTimeout(window.location.reload(), 800);

    } else {}
  },
  beforeSubmit: function(arr, $form, options) {
    if (!confirm("Bạn có chắc chắn chọn thao tác này không !"))
      return false;
  },
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php 
  $canUpdate = $hopdong->trangthaiduyet() != 0 ? false : true;
  $readonly = !$canUpdate ? 'readonly' : '';
  $approved = $hopdong->trangthaiduyet() == 1 ? true : false;
 ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <?php echo $__env->make('back.partials.ajax_form_messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($canUpdate): ?>
        <form class="form-horizontal" action="<?php echo e(route('api.hopdong.update', $hopdong->id)); ?>" method="post" id="form-update" enctype="multipart/form-data">
        <?php else: ?>
        <form action="<?php echo e(route('api.hopdong.action')); ?>" method="post" id="form-action-detail">
        <?php endif; ?>
          <?php echo e(csrf_field()); ?>

          <div class="card-body">
            <h4 class="card-title">
              Chỉnh sửa hợp đồng
              <?php if(!$canUpdate): ?>
                <?php if($hopdong->trangthaiduyet() == 1): ?>
                  <?php if(isAdminCP()): ?>
                  <span class="mc-notify badge badge-warning">Hợp đồng này đã được duyệt</span>
                  <?php else: ?>
                  <span class="mc-notify badge badge-warning">Hợp đồng này đã duyệt nên không thể chỉnh sửa</span>
                  <?php endif; ?>
                <?php else: ?>
                <span class="mc-notify badge badge-warning">Hợp đồng này đã gửi duyệt nên không thể chỉnh sửa</span>
                <?php endif; ?>
              <?php endif; ?>
              <?php if(isAdminCP() && $hopdong->trangthaiduyet() == 2): ?>
              <span class="mc-notify badge badge-info">Bạn có thể duyệt hợp đồng này</span>
              <?php endif; ?>
            </h4>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Số hợp đồng</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="sohopdong" id="sohopdong" placeholder="Số hợp đồng" value="<?php echo e($hopdong->sohopdong); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Tên hợp đồng</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="tenhopdong" id="tenhopdong" placeholder="Tên hợp đồng" value="<?php echo e($hopdong->tenhopdong); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Tên khách hàng</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="tenkhachhang" id="tenkhachhang" placeholder="Tên khách hàng" value="<?php echo e($hopdong->tenkhachhang); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Số điện thoại</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="sodienthoai" id="sodienthoai" placeholder="Số điện thoại" value="<?php echo e($hopdong->sodienthoai); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Địa chỉ email</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="email" id="email" placeholder="Địa chỉ email" value="<?php echo e($hopdong->email); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Địa chỉ</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="diachi" id="diachi" placeholder="Địa chỉ" value="<?php echo e($hopdong->diachi); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">Giá trị hợp đồng</label>
              <div class="col-md-10 mc-form-input">
                <input type="text" class="form-control" name="giatri" id="giatri" placeholder="Giá trị hợp đồng" value="<?php echo e($hopdong->giatri); ?>" <?php echo e($readonly); ?>>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-2 control-label col-form-label">File/Ảnh đính kèm</label>
              <div class="col-md-10 mc-form-input">
                <input type="file" class="custom-file-input" name="dinhkem" id="dinhkem" multiple="multiple">
              </div>
            </div>
            <div class="form-group row mc-no-margin-bottom">
              <div class="col-md-2"></div>
              <div class="col-md-10">
                <div class="progress">
                  <div class="progress-bar progress-bar-striped" id="send-process" role="progressbar" style="width: 0%" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="border-top">
            <div class="card-body">
              <?php if($canUpdate): ?>
              <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
              <?php else: ?>
              <?php if(isAdminCP()): ?>
                <input type="text" name="id[]" value="<?php echo e($hopdong->sohopdong); ?>" hidden>
                <input type="text" name="form_detail" value="true" hidden>
                <button type="submit" id="action-detail" class="btn btn-info" name="action" value="approve" <?php echo e($approved ? 'disabled' : ''); ?>>Duyệt hợp đồng</button>
              <?php endif; ?>
              <button type="submit" class="btn btn-primary" disabled>Chỉnh sửa</button>
              <?php endif; ?>
              <a href="<?php echo e(route('admin.hopdong.index')); ?>" class="btn btn-secondary">Quay lại</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>