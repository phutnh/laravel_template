<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <div class="block-header">
            <h5 class="card-title">Danh sách nhân sự</h5>
            <div class="block-tool">
              <a class="btn btn-success" href="<?php echo e(route('admin.qlnhansu.create')); ?>">Tạo mới</a>
            </div>
          </div>
          <table id="table-data-content" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Tên nhân sự</th>
                <th>Mã nhân sự</th>
                <th>Tài khoản</th>
                <th>Số di động</th>
                <th>Trạng thái</th>
                <th>Ngày tạo</th>
                <th>Ngày cập nhật</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $template['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user-> id); ?></td>
                    <td><a href="#"><?php echo e($user-> tennhanvien); ?></a></td>
                    <td><?php echo e($user-> manhanvien); ?></td>
                    <td><?php echo e($user-> taikhoan); ?></td>
                    <td><?php echo e($user-> sodidong); ?></td>
                    <td><?php echo e($user-> trangthai); ?></td>
                    <td><?php echo e($user-> created_at); ?></td>
                    <td><?php echo e($user-> updated_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>