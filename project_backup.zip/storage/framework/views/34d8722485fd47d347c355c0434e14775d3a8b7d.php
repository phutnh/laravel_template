<?php if(session('status')): ?>
  <div class="alert alert-success">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>

<?php if(session('messages')): ?>
  <div class="alert alert-success">
    <?php echo e(session('messages')); ?>

  </div>
<?php endif; ?>