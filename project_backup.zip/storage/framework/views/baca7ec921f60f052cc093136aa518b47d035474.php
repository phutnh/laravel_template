        <footer class="footer text-center">
          All Rights Reserved by Matrix-admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
      </div>
      <!-- ============================================================== -->
      <!-- End Page wrapper  -->
      <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('js/admincp/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/waves.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admincp/sidebarmenu.j')); ?>s"></script>
    <script src="<?php echo e(asset('js/admincp/custom.min.js')); ?>"></script>
  </body>
</html>