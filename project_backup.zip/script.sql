update nhanvien set hoahongtamtinh = 0;
update nhanvien set soduthucte = 0;

update hopdong set trangthai = "Gửi duyệt"