<?php

return [
	'admin' => [
		'path_css' => 'css/admincp/',
		'path_js' => 'js/admincp/'
	],
];