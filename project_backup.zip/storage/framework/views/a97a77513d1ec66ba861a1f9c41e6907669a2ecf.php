<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
apiData = '<?php echo e(route('api.hopdong.all')); ?>';
</script>
<script src="<?php echo e(asset(config('setting.admin.path_js') . 'hopdong.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <?php echo $__env->make('back.partials.ajax_form_messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card-body">
          <form action="<?php echo e(route('api.hopdong.action')); ?>" method="post" id="form-data-hopdong">
            <?php echo e(csrf_field()); ?>

            <div class="block-header">
              <h5 class="card-title">Danh sách hợp đồng</h5>
              <div class="block-tool">
                <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.hopdong.create')); ?>"><i class="mdi mdi-plus-box"></i> Tạo mới</a>
                <?php if(isAdminCP()): ?>
                <button class="btn btn-info btn-sm" name="action" value="approve" type="submit"><i class="mdi mdi-marker-check"></i> Duyệt hợp đồng</button>
                <?php endif; ?>
                <button class="btn btn-primary btn-sm" name="action" value="send" type="submit"><i class="mdi mdi-marker-check"></i> Gửi duyệt</button>
                <button class="btn btn-danger btn-sm" name="action" value="delete" type="submit"><i class="mdi mdi-delete-empty"></i> Xóa bỏ</button>
              </div>
            </div>
            <div class="table-responsive">
              <table id="table-data-content" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th width="auto"></th>
                    <th width="15">
                      <!--<input name="select_all" value="all" id="ckb-select-all" type="checkbox" />-->
                      <label class="mc-container">&nbsp;
                        <input type="checkbox" value="all" id="ckb-select-all">
                        <span class="mc-checkmark"></span>
                      </label>
                    </th>
                    <th>Số hợp đồng</th>
                    <th>Tên hợp đồng</th>
                    <th>Khách hàng</th>
                    <th>Giá trị</th>
                    <th>Trạng thái</th>
                    <th width="auto">Công cụ</th>
                  </tr>
                </thead>
              </table>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>