@extends('front.layouts.app')

@section('content')
	<a href="{{ route('login') }}">Đăng nhập</a><br/>
	<a href="#">Đăng ký</a>
@endsection
