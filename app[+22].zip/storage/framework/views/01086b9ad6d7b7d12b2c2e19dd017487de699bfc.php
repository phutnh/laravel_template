<div class="page-breadcrumb">
  <div class="row">
    <div class="col-12 d-flex no-block align-items-center">
      <h4 class="page-title"><?php echo e($template['title-breadcrumb']); ?></h4>
      <div class="ml-auto text-right">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(route('admin.dashboard')); ?>">Trang chủ</a>
            </li>
            <?php $__currentLoopData = $template['breadcrumbs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($breadcrumb['active']): ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($breadcrumb['name']); ?></li>
            <?php else: ?>
            <li class="breadcrumb-item">
              <a href="<?php echo e($breadcrumb['link']); ?>"><?php echo e($breadcrumb['name']); ?></a>
            </li>
            <?php endif; ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</div>