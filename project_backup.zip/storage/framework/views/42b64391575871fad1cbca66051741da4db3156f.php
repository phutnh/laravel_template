<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
         <!--<?php echo $__env->make('back.partials.ajax_form_messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>-->
        <form class="form-horizontal" action="<?php echo e(route('admin.thamso.action', $thamso->id)); ?>" method="POST" id="form-edit" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="card-body">
            <h4 class="card-title">Chỉnh sửa tham số hoa hồng</h4>
            <div class="form-group row">
              <label class="col-md-3 control-label col-form-label">Mã tham số</label>
              <div class="col-md-9 mc-form-input">
                <input type="text" class="form-control" name="txtmathamso" id="txtmathamso" value="<?php echo e($thamso->mathamso); ?>"  readonly>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-3 control-label col-form-label">Tên tham số</label>
              <div class="col-md-9 mc-form-input">
                <input type="text" class="form-control" name="txttenthamso" id="txttenthamso" value="<?php echo e($thamso->tenthamso); ?>" maxlength="50" placeholder="Tên tham số">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-3 control-label col-form-label">Mô tả thông tin tham số</label>
              <div class="col-md-9 mc-form-input">
                <textarea class="form-control" rows="10" name="txtthongtinthamso" id="txtthongtinthamso" maxlength="500" placeholder="Mô tả thông tin tham số"><?php echo $thamso->mota; ?></textarea>
              </div>
            </div><div class="form-group row">
              <label class="col-md-3 control-label col-form-label">Giá trị tham số</label>
              <div class="col-md-9 mc-form-input">
                <input type="number" class="form-control" min="1" max="100" name="txtgiatrithamso" id="txtgiatrithamso" value="<?php echo e($thamso->giatrithamso); ?>" placeholder="Tên tham số">
              </div>
            </div>
          </div>
          <div class="border-top">
            <div class="card-body">
              <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
              <a href="<?php echo e(route('admin.thamso.index')); ?>" class="btn btn-secondary">Quay lại</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>