<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('login')); ?>">Đăng nhập</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>